package ui;

import java.util.Scanner;

import javax.annotation.processing.SupportedOptions;
import javax.sound.sampled.SourceDataLine;
import java.time.LocalDate;
import java.sql.Date;


import model.NeoTunesController;

public class NeoTunesApp {

    // Relations
    private NeoTunesController shop;

    public static Scanner lector = new Scanner(System.in);

    public NeoTunesApp() {

        shop = new NeoTunesController();
    }

    public static void main(String args[]) {
        NeoTunesApp objMain = new NeoTunesApp();
        objMain.menu();
        
       
        

    }

    public void menu() {

        int option = 0;

        while (option != 15) {
            System.out.println(" == Menu == ");
            System.out.println("1. Register consumer users.");
            System.out.println("2. Register producer users.");
            System.out.println("3. Create a song or podcast.");
            System.out.println("4. Create a playlist.");
            System.out.println("5. Edit a playlist.");
            System.out.println("6. Share a playlist.");
            System.out.println("7. Play a song or podcast");
            System.out.println("8. total views across the platform.");
            System.out.println("9. Report the most listened song genre for a user and for the entire platform.");
            System.out.println("10. Report the most listened to podcast category.");
            System.out.println("11. Top 5 artists and Top 5 content creators on the platform.");
            System.out.println("12. Top 10 songs and Top 10 podcast.");
            System.out.println("13. Inform for each genre the number of songs sold and the total value of sales.");
            System.out.println("14. The best-selling song on the platform.");
            System.out.println("15. Exit menu.");

           

            option = lector.nextInt();
            lector.nextLine();

            switch (option) {

                case 1:
                    registerConsumer();
                    break;

                case 2:
                    registerProducer();
                    break;

                case 3:
                    createSongOrPodcast();
                    break;

                case 4:

                    break;

                case 5:

                    break;

                case 6:

                    break;

                case 7:

                    break;

                case 8:

                    break;

                case 9:

                    break;
                
                case 10:
                     
                    break;


                case 11:
                     
                    break;

                case 12:
                     
                    break;

                case 13:
                     
                    break;

                case 14:
                     
                    break;
                
                case 15:
                     System.out.println("Exiting...");
                    break;

                default:
                    System.out.println("Option out of range.");
                    break;
            }
        }

    }


    public void registerConsumer(){

       System.out.println("Select the type of consumer\n1. Standard.\n2. Premium.");
        int option = lector.nextInt();
        lector.nextLine();

        System.out.println("Please type the nickname");
        String nickname = lector.nextLine();

      System.out.println("Please type the document");
        String document = lector.nextLine();

        LocalDate vinculationDate= LocalDate.now();
       
        System.out.println(shop.addUser(nickname, document, vinculationDate, option));

    }

    public void registerProducer(){
        System.out.println("Select the type of producer\n1. Artist.\n2. Content creator.");
            int option= lector.nextInt();
            lector.nextLine();

        System.out.println("Please type the name");
            String nickName= lector.nextLine();
           
            System.out.println("Please type the document");
            String document = lector.nextLine();  
            
            LocalDate dateProducer= LocalDate.now();
             
            System.out.println("Please type the name");
            String name=lector.nextLine();

            System.out.println("Please type the url");
            String imageUrl=lector.nextLine();

        System.out.println(shop.addUser(nickName, document, dateProducer, name, imageUrl, option));
    }

    public void createSongOrPodcast(){
        System.out.println("Select one:\n1. Song\n2. Podcast");
            int option = lector.nextInt();
            lector.nextLine();
        
        System.out.println("Please type the name");
            String name = lector.nextLine();
        
        if(option==1){
            System.out.println("Type the name of the album");
            String album = lector.nextLine();
            
            System.out.println("Select a gender.\n1. Rock\n2. Pop.\n3. Trap.\n4. House.");
            int optionGender= lector.nextInt();
            lector.nextLine();

            System.out.println("Type the url of the cover");
            String cover=lector.nextLine();

            System.out.println("Please type the duration");
            double duration = lector.nextDouble();
            lector.nextLine();

            System.out.println("Type the value of the song");
            double value= lector.nextDouble();
            lector.nextLine();

            System.out.println(shop.addSong(name, album, optionGender, cover, duration, value, option, option));
            //numero de reproducciones
            //numero de veces vendidas
        }
        else if(option==2){

            System.out.println("Please type a description");
            String description = lector.nextLine();
            
            System.out.println("Select a category.\n1. Politic.\n2. Entertainment.\n3. Videogames.\n4. Fashion.");
            int optionCategory= lector.nextInt();
            lector.nextLine();

            System.out.println("Please type the url of the image");
            String urlImagePodcast=lector.nextLine();

            System.out.println("Please type the duration");
            double duration = lector.nextDouble();
            lector.nextLine();

            //NUMERO DE REPRODUCCIONES EN LA CONTROLER YA Q AQUI ES 0

        }
    }
}
