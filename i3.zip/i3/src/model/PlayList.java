package model;

public class PlayList {


    public PlayList() {
    }
}