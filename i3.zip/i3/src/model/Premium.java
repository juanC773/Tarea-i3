package model;

import java.time.LocalDate;

public class Premium extends Consumer {

    /*todo el catalogo
     * canciones ilimitadas
     * listas de reproduccion ilimitadas
     */
    public Premium(String nickName, String cedula, LocalDate date) {
           super(nickName, cedula, date);
    }
}