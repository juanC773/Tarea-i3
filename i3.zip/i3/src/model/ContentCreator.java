package model;

import java.time.LocalDate;

public class ContentCreator extends Producer{

    public ContentCreator(String nickName, String cedula, LocalDate date, String name, String imageProducerUrl) {
           super(nickName, cedula, date, name, imageProducerUrl);
    }
}