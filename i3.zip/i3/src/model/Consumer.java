package model;

import java.time.LocalDate;

public class Consumer extends User {

    /*
     *  para cada tipo de contenido, el acumulado de tiempo reproducido, 
     * el género o categoría más escuchado y el artista y creador de contenido más escuchados. 
     */


    public Consumer(String nickName, String document, LocalDate date) { 
       
        super(nickName, document, date);
    }
}