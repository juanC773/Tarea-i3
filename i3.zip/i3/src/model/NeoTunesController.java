package model;

import java.time.LocalDate;
import java.util.ArrayList;

public class NeoTunesController {

    //Relations
    private ArrayList<User> users;
    private ArrayList<Audio> audios;
    private ArrayList<Podcast> podcasts;

    public NeoTunesController() {
        users= new ArrayList<User>();
        
        podcasts= new ArrayList<Podcast>();
        audios= new ArrayList<Audio>();
    }


    public boolean searchUser(String document){
       boolean exist=true;
       
       for (int i = 0; i < users.size(); i++) {
            if(users.get(i).getDocument ().equals(document))
            exist=false;
       }

       return exist;
    }

    public String addUser(String nickName, String document, LocalDate date, int option){
        
        String message="";
        boolean confirm=searchUser(document);
       
        
        if(confirm & option==1){
             Standard objStandard= new Standard(nickName, document, date);
            users.add(objStandard);
            message="The standard user was created successfully.";
        }
        else if(confirm & option==2){
            Premium objPremium= new Premium(nickName, document, date);
            users.add(objPremium); 
            message="The premium user was created successfully."; 
        }
        else if(!confirm){
            message="It could not be created because there is already someone with this same document.";
        }
      return message;
    }
    

    public String addUser(String nickName, String document, LocalDate date, String name, String imageProducerUrl, int option){
        String message="";

        boolean confirm=searchUser(document);
        
        if(confirm & option==1){
            Artist objArtist= new Artist(nickName, document, date, name, imageProducerUrl);
            users.add(objArtist);
            message="The Artist user was created successfully.";
        }
        else if(confirm & option==2){
            ContentCreator objContentCreator= new ContentCreator(nickName, document, date, name, imageProducerUrl);
            users.add(objContentCreator);
            message="The creator user was created successfully.";
        }
        else if(!confirm){
            message="It could not be created because there is already someone with this same document.";
        }
        return message;
    }

    
    public String addSong(String name, String album, int option,String urlCover, double duration, double value, int numberOfReproduction,int numberOfSell){
        String messsage="The song was created correctly";

        TypeGender gender = null;
		if (option == 1) {
			gender = TypeGender.ROCK;

		} else if (option == 2) {
			gender = TypeGender.POP;

		} else if (option == 3) {
			gender = TypeGender.TRAP;

		} else if (option == 4) {
			gender = TypeGender.HOUSE;
		}

        Song objSong= new Song(name, album, gender, urlCover, duration, value, numberOfReproduction, numberOfSell);
        songs.add(objSong);
        
        return messsage;
    }


    public String addPodcast(String name,String description, int option, String urlImage, double duration, int numberOfReprodution){
        String messsage="The podcast was created correctly";
        
        TypeCategory category = null;
		if (option == 1) {
			category = TypeCategory.POLITIC;

		} else if (option == 2) {
			category = TypeCategory.ENTERTAIMENT;

		} else if (option == 3) {
			category = TypeCategory.VIDEOGAME;

		} else if (option == 4) {
			category = TypeCategory.FASHION;
		}

        Podcast objPodcast= new Podcast(name, description, category, urlImage, duration, numberOfReprodution);
        podcasts.add(objPodcast);
        return messsage;
    }
}