package model;

public enum TypeCategory {

    POLITIC, ENTERTAIMENT, VIDEOGAME, FASHION;
}