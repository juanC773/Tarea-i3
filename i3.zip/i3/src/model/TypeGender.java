package model;

public enum TypeGender {

    ROCK, POP, TRAP, HOUSE;
}