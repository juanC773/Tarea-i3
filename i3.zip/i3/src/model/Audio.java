package model;

public class Audio {

    public Audio() {

    }

}