package model;

import java.time.LocalDate;

public class Standard extends Consumer {

    /*acceso al catalogo de audio.
     *hasta 20 listas de reproducción.
     *hasta 100 canciones
     */
    public Standard(String nickName, String cedula, LocalDate date) {
        super(nickName, cedula, date);

    }
}