package model;

import java.time.LocalDate;

public class Artist extends Producer {

    public Artist(String nickName, String cedula, LocalDate date, String name, String imageProducerUrl) {
        super(nickName, cedula, date, name, imageProducerUrl);

    }
}