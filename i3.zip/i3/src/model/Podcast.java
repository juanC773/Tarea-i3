package model;

public class Podcast {

    private String name;
    private String description;
    private TypeCategory category;
    private String urlImage;
    private double duration;
    private int numberOfReprodution;
    

    public Podcast(String name,String description, TypeCategory category, String urlImage, double duration, int numberOfReprodution) {

        this.name=name;
        this.description=description;
        this.category=category;
        this.urlImage=urlImage;
        this.duration=duration;
        this.numberOfReprodution=numberOfReprodution;
    }


    public String getName() {
        return name;
    }


    public void setName(String name) {
        this.name = name;
    }


    public String getDescription() {
        return description;
    }


    public void setDescription(String description) {
        this.description = description;
    }


    public TypeCategory getCategory() {
        return category;
    }


    public void setCategory(TypeCategory category) {
        this.category = category;
    }


    public String getUrlImage() {
        return urlImage;
    }


    public void setUrlImage(String urlImage) {
        this.urlImage = urlImage;
    }


    public double getDuration() {
        return duration;
    }


    public void setDuration(double duration) {
        this.duration = duration;
    }


    public int getNumberOfReprodution() {
        return numberOfReprodution;
    }


    public void setNumberOfReprodution(int numberOfReprodution) {
        this.numberOfReprodution = numberOfReprodution;
    }

    
}