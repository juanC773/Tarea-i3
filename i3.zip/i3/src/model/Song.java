package model;

public class Song {
    
    private String name;
    private String album;
    private TypeGender gender;
    private String urlCover;
    private double duration;
    private double value;
    private int numberOfReproduction;
    private int numberOfSell;

    public Song(String name, String album, TypeGender gender,String urlCover, double duration, double value, int numberOfReproduction,int numberOfSell ) {
       this.name=name;
       this.album=album;
       this.gender=gender;
       this.urlCover=urlCover;
       this.duration=duration;
       this.value=value;
       this.numberOfReproduction=numberOfReproduction;
       this.numberOfSell=numberOfSell;
    }



    public String getName() {
        return name;
    }

    public String getAlbum() {
        return album;
    }

    public TypeGender getGender() {
        return gender;
    }

    public String getUrlCover() {
        return urlCover;
    }

    public double getDuration() {
        return duration;
    }

    public double getValue() {
        return value;
    }

    public int getNumberOfReproduction() {
        return numberOfReproduction;
    }

    public int getNumberOfSell() {
        return numberOfSell;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAlbum(String album) {
        this.album = album;
    }

    public void setGender(TypeGender gender) {
        this.gender = gender;
    }

    public void setUrlCover(String urlCover) {
        this.urlCover = urlCover;
    }

    public void setDuration(double duration) {
        this.duration = duration;
    }

    public void setValue(double value) {
        this.value = value;
    }

    public void setNumberOfReproduction(int numberOfReproduction) {
        this.numberOfReproduction = numberOfReproduction;
    }

    public void setNumberOfSell(int numberOfSell) {
        this.numberOfSell = numberOfSell;
    }    
}