package ui;

import java.util.Scanner;

import javax.annotation.processing.SupportedOptions;
import javax.lang.model.util.ElementScanner14;
import javax.sound.sampled.SourceDataLine;
import java.time.LocalDate;
import java.rmi.StubNotFoundException;
import java.sql.Date;
import java.util.Random;

import model.NeoTunesController;

public class NeoTunesApp {

    // Relations
    private NeoTunesController shop;

    public static Scanner lector = new Scanner(System.in);

    public NeoTunesApp() {

        shop = new NeoTunesController();
    }

    /**
     * Main
     * 
     * @param args
     */
    public static void main(String args[]) {
        NeoTunesApp objMain = new NeoTunesApp();
        objMain.menu();

    }

    public void menu() {
        int option = 0;
        while (option != 10) {
            System.out.println(" <==NeoTunes menu ==> ");
            System.out.println("1. Register consumer users.");
            System.out.println("2. Register producer users.");
            System.out.println("3. Create a song or podcast.");
            System.out.println("4. Create a playlist.");
            System.out.println("5. Edit a playlist.");
            System.out.println("6. Share a playlist.");
            System.out.println("7. Play a song or podcast");
            System.out.println("8. Buy a song");
            System.out.println("9. Rankings.");
            System.out.println("10. Exit menu.");
            option = lector.nextInt();
            lector.nextLine();

            switch (option) {
                case 1:
                    registerConsumer();
                    break;
                case 2:
                    registerProducer();
                    break;
                case 3:
                    createAudio();
                    break;
                case 4:
                    createAPlaylist();
                    break;
                case 5:
                    editAPlaylist();
                    break;
                case 6:
                    shareAPlaylist();
                    break;
                case 7:
                    reproduceAudio();
                    break;
                case 8:
                    buyASong();
                    break;
                case 9:
                    generateRankings();
                    break;
                case 10:
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Option out of range.");
                    break;
            }
        }

    }

    /**
     * Receives the information to create consumer type users
     */
    public void registerConsumer() {

        System.out.println("Select the type of consumer\n1. Standard.\n2. Premium.");
        int option = lector.nextInt();
        lector.nextLine();

        System.out.println("Please type the nickname");
        String nickname = lector.nextLine();

        System.out.println("Please type the document");
        String document = lector.nextLine();

        LocalDate vinculationDate = LocalDate.now();

        System.out.println(shop.addUser(nickname, document, vinculationDate, option));

    }

    // Receives the information to create producer type users.
    public void registerProducer() {

        System.out.println("Select the type of producer\n1. Artist.\n2. Content creator.");
        int option = lector.nextInt();
        lector.nextLine();

        System.out.println("Please type the nickname");
        String nickName = lector.nextLine();

        System.out.println("Please type the document");
        String document = lector.nextLine();

        LocalDate dateProducer = LocalDate.now();

        System.out.println("Please type the name");
        String name = lector.nextLine();

        System.out.println("Please type the url");
        String imageUrl = lector.nextLine();

        System.out.println(shop.addUser(nickName, document, dateProducer, name, imageUrl, option));
    }

    // Receive the information to create a audio.
    public void createAudio() {

        System.out.println("Select one:\n1. Song\n2. Podcast");
        int option = lector.nextInt();
        lector.nextLine();

        System.out.println("Type the nickname of the artist");
        String nicknameToSearch = lector.nextLine();
        boolean exist = shop.searchNickname(nicknameToSearch);

        if (exist) {
            System.out.println("Please type the name");
            String name = lector.nextLine();

            if (option == 1) {
                System.out.println("Type the name of the album");
                String album = lector.nextLine();

                System.out.println("Select a gender.\n1. Rock\n2. Pop.\n3. Trap.\n4. House.");
                int optionGender = lector.nextInt();
                lector.nextLine();

                System.out.println("Type the url of the cover");
                String cover = lector.nextLine();

                System.out.println("Please type the duration");
                double duration = lector.nextDouble();
                lector.nextLine();

                System.out.println("Type the value of the song");
                int value = lector.nextInt();
                lector.nextLine();

                int numberOfReproduction = 0;
                int numberOfSell = 0;

                System.out.println(shop.addAudio(nicknameToSearch, name, cover, duration, numberOfReproduction, album,
                        optionGender, value, numberOfSell));

            } else if (option == 2) {

                System.out.println("Please type a description");
                String description = lector.nextLine();

                System.out.println("Select a category.\n1. Politic.\n2. Entertainment.\n3. Videogames.\n4. Fashion.");
                int optionCategory = lector.nextInt();
                lector.nextLine();

                System.out.println("Please type the url of the image");
                String urlImagePodcast = lector.nextLine();

                System.out.println("Please type the duration");
                double duration = lector.nextDouble();
                lector.nextLine();

                int numberOfReproduction = 0;
                shop.addAudio(nicknameToSearch, name, description, optionCategory, urlImagePodcast, duration,
                        numberOfReproduction);

            }
        } else {
            System.out.println("This artist don't exist");
        }

    }

    // Create the playlist.
    public void createAPlaylist() {

        System.out.println("Select one:\n1.Standard\n2.Premium.");
        int optionOfConsumer = lector.nextInt();
        lector.nextLine();

        System.out.println("Type the nickname of the user");
        String nickNameToSearch = lector.nextLine();
        boolean confirm = shop.searchNickname(nickNameToSearch);

        if (confirm) {

            System.out.println("Type the name of the playlist");
            String namePlaylist = lector.nextLine();

            System.out.println("select one:\n1.Only Songs.\n2.Only Podcast.\n3.Songs and Podcast.");
            int optionPlaylist = lector.nextInt();
            lector.nextLine();

            System.out.println(shop.createPlaylist(optionOfConsumer, nickNameToSearch, namePlaylist, optionPlaylist));

        } else {
            System.out.println("This user doesn't exist");
        }
    }

    // Edit a playlist
    public void editAPlaylist() {

        System.out.println("Type the user whose playlist you want to edit");
        String nickNameUser = lector.nextLine();
        boolean confirm = shop.searchNickname(nickNameUser);

        if (confirm) {

            System.out.println(shop.printPlaylist(nickNameUser));
            int optionPlaylist = lector.nextInt();
            lector.nextLine();

            System.out.println("select one:\n1.Add Song\n2.Delete Song");
            int optionToEdit = lector.nextInt();
            lector.nextLine();

            if (optionToEdit == 1) {
                System.out.println(shop.printCatalogue());
                System.out.println("Select one audio");
                int chosenSong = lector.nextInt();
                lector.nextLine();

                System.out.println(shop.editPlaylist(optionToEdit, optionPlaylist, chosenSong, nickNameUser));
            } else if (optionToEdit == 2) {
                System.out.println(shop.audiosOfAplaylist(optionPlaylist, nickNameUser));
                int selectSong = lector.nextInt();
                lector.nextLine();

                System.out.println(shop.editPlaylist(optionToEdit, optionPlaylist, selectSong, nickNameUser));

            }

        } else {

            System.out.println("The playlist doesn't exist");
        }

    }

    // Share a playlist
    public void shareAPlaylist() {

        System.out.println("enter the nickName that will share the playlist");
        String nameUser = lector.nextLine();
        boolean exist = shop.searchNickname(nameUser);

        if (exist) {
            System.out.println("What playlist do you want to share?");
            System.out.println(shop.printPlaylist(nameUser));
            int playlistSelect = lector.nextInt();
            lector.nextLine();
            System.out.println(shop.sharePlaylist(nameUser, playlistSelect));
        } else {
            System.out.println("The user doesn't exist");
        }
    }

    // Reproduce a audio
    public void reproduceAudio() {

        System.out.println("Type the nickname of the user");
        String nameUser = lector.nextLine();
        boolean exist = shop.searchNickname(nameUser);

        if (exist) {
            System.out.println("Choose a song to reproduce");
            System.out.println(shop.printCatalogue());
            System.out.println("Select one");
            int songSelected = lector.nextInt();
            lector.nextLine();
            System.out.println(shop.reproduceAudio(nameUser, songSelected));
        } else {
            System.out.println("The user doesn't exist");
        }

    }

    // Buy a song
    public void buyASong() {

        System.out.println("Type the name of the user");
        String user = lector.nextLine();
        boolean confirmExist = shop.searchNickname(user);

        if (confirmExist) {
            System.out.println(shop.printAllSong());
            System.out.println("Please, select the song to buy");
            int songToBuy = lector.nextInt();

            System.out.println(shop.buyASong(songToBuy, user));

        } else {
            System.out.println("The user doesn't exist");
        }
    }

    // Generate reports
    public void generateRankings() {
        System.out.println(
                "Select one\n1. The cumulative total of views across the entire platform.\n2. Report the most listened song genre for a user and for the entire platform.\n3. Report the most listened to podcast category.\n4. Top 5 artists and Top 5 content creators on the platform.\n5. Top 10 songs and Top 10 podcast.\n6. Inform for each genre the number of songs sold and the total value of sales.\n7.The best-selling song on the platform.");
        int option = lector.nextInt();
        lector.nextLine();

        if (option == 1) {
            System.out.println(shop.totalReproduction());

        } else if (option == 2) {
            System.out.println("Type the name of the user");
            String nameUser = lector.nextLine();
            boolean exist = shop.searchNickname(nameUser);
            if (exist) {
                System.out.println("Select one:\n1.All plataform\n2. One user");
                int optionSelect = lector.nextInt();
                lector.nextLine();
                System.out.println((shop.mostListenedGenre(optionSelect, nameUser)));
            } else {
                System.out.println("The user doesn't exist");
            }
        } else if (option == 3) {

            System.out.println("Type the name of the user");
            String nameUser = lector.nextLine();
            boolean exist = shop.searchNickname(nameUser);
            if (exist) {
                System.out.println("Select one:\n1.All plataform\n2. One user");
                int optionSelect = lector.nextInt();
                lector.nextLine();
                System.out.println((shop.mostListenedPodcast(optionSelect, nameUser)));
            } else {
                System.out.println("The user doesn't exist");
            }
        } else if (option == 4) {
            System.out.println("....");
        } else if (option == 5) {
            System.out.println("...");
        } else if (option == 6) {
            System.out.println(shop.salesOfEachGenre());
        } else if (option == 7) {
            System.out.println(shop.bestSellingSong());
        }
    }

}
