package model;

import java.time.LocalDate;
import java.util.ArrayList;

public class Artist extends Producer {


    //relations
    private ArrayList<Song> mySongs;
    
    
    /**
      * name: Artist
      * The builder.
      * @param nicknameName contains the nickname of the artist
      * @param document contains the artist's document
      * @param date contains the date
      * @param name contains the name of the artist
      * @param imageProducerUrl contains the url of the artist image
     */
    public Artist(String nickName, String document, LocalDate date, String name, String imageProducerUrl) {
        super(nickName, document, date, name, imageProducerUrl);

        mySongs= new ArrayList<Song>();
        
    }


    //Get and set

    public ArrayList<Song> getMySongs() {
        return mySongs;
    }

    public void setMySongs(ArrayList<Song> mySongs) {
        this.mySongs = mySongs;
    }




    






    
}