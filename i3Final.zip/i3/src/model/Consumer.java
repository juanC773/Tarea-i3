package model;

import java.time.LocalDate;
import java.util.ArrayList;

public class Consumer extends User {


    protected ArrayList<PlayList> objPlayList;
    /*
     *  para cada tipo de contenido, el acumulado de tiempo reproducido, 
     * el género o categoría más escuchado y el artista y creador de contenido más escuchados. 
     */

    /**
     * Name: Consumer
      * The builder
      * @param nicknameName Contains the consumer's nickname
      * @param document Contains the consumer document
      * @param date Contains the date
      */
    public Consumer(String nickName, String document, LocalDate date) { 
       
        super(nickName, document, date);
        objPlayList= new ArrayList<PlayList>();
    }


}