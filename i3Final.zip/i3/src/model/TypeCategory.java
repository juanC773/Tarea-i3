package model;

//Enum of category (podcast)
public enum TypeCategory {

    POLITIC, ENTERTAIMENT, VIDEOGAME, FASHION;
}