package model;
import java.util.ArrayList;

//Reproduce audio
interface Playable {
    public String playAudio(int positionAudio, ArrayList<Audio> audios);

}