package model;

import java.time.LocalDate;
import java.util.ArrayList;

public class ContentCreator extends Producer{
    
    //Atributtes
    private ArrayList<Podcast> myPodcast;

   /**
    * name: ContentCreator
     * The constructor.
     *@param nickName Contiene el nickname del creador de contenido.
    * @param document Contiene el documento del creador de contenido.
    * @param date Contiene la fecha
    * @param name Contiene el nombre del creador de contenido.
    * @param imageProducerUrl Contiene el url del creador de contenido.
    */
    public ContentCreator(String nickName, String document, LocalDate date, String name, String imageProducerUrl) {
           super(nickName, document, date, name, imageProducerUrl);

           myPodcast= new ArrayList<Podcast>();
    }

    //Get and set
public ArrayList<Podcast> getMyPodcast() {
    return myPodcast;
}

public void setMyPodcast(ArrayList<Podcast> myPodcast) {
    this.myPodcast = myPodcast;
}

    
}