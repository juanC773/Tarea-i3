package model;
import java.util.ArrayList;

public abstract class Audio {



    //Atributtes
    String name;
    String url;
    double duration;
    int numberOfReproduction;


    /**
     *  name: Audio
      * The builder.
      * @param name contains the name of the audio
      * @param url Contains the url of the audio
      * @param duration Contains the duration of the audio
      * @param numberOfReproduction Contains the reproduction number of the audio
     */

    public Audio(String name, String url, double duration, int numberOfReproduction) {

       

        this.name=name;
        this.url=url;
        this.duration=duration;
        this.numberOfReproduction=numberOfReproduction;

    }

    


    //Get and Set
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }


    public String getUrl() {
        return url;
    }


    public void setUrl(String url) {
        this.url = url;
    }


    public double getDuration() {
        return duration;
    }


    public void setDuration(double duration) {
        this.duration = duration;
    }


    public int getNumberOfReproduction() {
        return numberOfReproduction;
    }


    public void setNumberOfReproduction(int numberOfReproduction) {
        this.numberOfReproduction = numberOfReproduction;
    }


    

}