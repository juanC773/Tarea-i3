package model;

//Enum of gender (Song)
public enum TypeGender {

    ROCK, POP, TRAP, HOUSE;
}