package model;

import java.time.LocalDate;

public class Producer extends User {

   private String name;
   private String imageProducerUrl;

   /*
    * se desea saber el número acumulado de reproducciones y el total de tiempo reproducido por los usuarios consumidores.
    */
    
    /**
     *  name: Producer
      * The builder.
      * @param nicknameName Contains the nickname of the producer
      * @param document Contains the producer document
      * @param date Contains the date
      * @param name Contains the name of the producer
      * @param imageProducerUrl Contains the url
     */
    public Producer(String nickName, String document, LocalDate date, String name, String imageProducerUrl) {
        super(nickName, document, date);
        this.name=name;
        this.imageProducerUrl=imageProducerUrl;
    }

    //Get and Set

    public String getName() {
        return name;
    }

    public String getImageProducerUrl() {
        return imageProducerUrl;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setImageProducerUrl(String imageProducerUrl) {
        this.imageProducerUrl = imageProducerUrl;
    }

    
}