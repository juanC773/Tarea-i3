package model;

import java.time.LocalDate;
import java.util.ArrayList;

public class Premium extends Consumer implements Playable {

    /*todo el catalogo
     * canciones ilimitadas
     * listas de reproduccion ilimitadas
     */
    
     //relations
    private ArrayList<Song> mySongs;
    private ArrayList<PlayList>myPlayLists;
    private ArrayList<Song> mySongsListened;
    private ArrayList<Podcast> myPodcastListened;
      
    

    /**
      * name: Premium
      * The builder.
      * @param nicknameName Contains the nickname of the premium user
      * @param document Contains the premium user's document
      * @param date Contains the binding date
     */
    public Premium(String nickName, String document, LocalDate date) {
           super(nickName, document, date);

           mySongs= new ArrayList<Song>();
           myPlayLists= new ArrayList<PlayList>();
           this.mySongsListened= new ArrayList<Song>();
           myPodcastListened=new ArrayList<Podcast>();
    }


     /**
      * name: playAudio
       * Play an audio
       * @param positionAudio Contains the index indicating which audio should be played
       * @param audios Contains the audios and podcast (arraylist)
       * @return Returns a message indicating whether or not the audio was played
       *(Requires the existence of audios)
       */
    @Override
    public String playAudio(int positionAudio, ArrayList<Audio> audios) {
        
        String msg = "The audio doesn't exist";
       
        for(int i=0; i<audios.size(); i++){
                if(audios.get(positionAudio) instanceof Song){
                  
                        msg = "Reproducing\n" + audios.get(positionAudio).getName() + "...\n";
                }
                else if(audios.get(positionAudio) instanceof Podcast){
                    msg= " Reproducing..."+" \n"+audios.get(positionAudio).getName()+" ...";
                }
            }
        return msg;
    }


    //Get and Set

    
    public ArrayList<Song> getMySongs() {
        return mySongs;
    }




    public void setMySongs(ArrayList<Song> mySongs) {
        this.mySongs = mySongs;
    }



    public ArrayList<PlayList> getMyPlayLists() {
        return myPlayLists;
    }




    public void setMyPlayLists(ArrayList<PlayList> myPlayLists) {
        this.myPlayLists = myPlayLists;
    }


    public ArrayList<Song> getMySongsListened() {
        return mySongsListened;
    }


    public void setMySongsListened(ArrayList<Song> mySongsListened) {
        this.mySongsListened = mySongsListened;
    }


    public ArrayList<Podcast> getMyPodcastListened() {
        return myPodcastListened;
    }


    public void setMyPodcastListened(ArrayList<Podcast> myPodcastListened) {
        this.myPodcastListened = myPodcastListened;
    }
    
}