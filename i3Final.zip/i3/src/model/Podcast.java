package model;

import java.lang.reflect.Type;

public class Podcast extends Audio{

    //Atributtes
    private String description;
    private TypeCategory category;

    
    /**
      * name: podcast
      * The builder.
      * @param name Contains the name of the podcast.
      * @param description Contains the description of the podcast
      * @param category contains the category of the podcast
      * @param urlImage Contains the podcast url
      * @param duration contains the duration of the podcast
      * @param numberOfReprodution Contains the number of reproductions of the podcast
     */
    public Podcast(String name,String description, TypeCategory category, String urlImage, double duration, int numberOfReprodution) {
        super(name, urlImage, duration, numberOfReprodution);
        
        this.description=description;
        this.category=category;
    }

    //To String
    @Override
    public String toString() {
        return "Podcast ["+"name: "+super.getName()+" description= "+ description + ", category= " + category + "]"+"\n";
    }


     //Get and Set
     public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }



    public TypeCategory getCategory() {
        return category;
    }



    public void setCategory(TypeCategory category) {
        this.category = category;
    }


    

    
}