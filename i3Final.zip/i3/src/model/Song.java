package model;

public class Song extends Audio {
    
    
    private String album;
    private TypeGender gender;
    private int value;
    private int numberOfSell;
 

    /**
     *  name: song
      * The builder.
      * @param name Contains the name of the song
      * @param album Contains the name of the album
      * @param gender Contains the genre of the song
      * @param urlCover Contains the url
      * @param duration Contains the duration of the song
      * @param value Contains the price of the song
      * @param numberOfReproduction Contains the number of reproductions
      * @param numberOfSell Contains the number of sales
     */
    public Song(String name, String album, TypeGender gender,String urlCover, double duration, int value, int numberOfReproduction,int numberOfSell ) {
         super(name, urlCover, duration, numberOfReproduction);      
       
       this.album=album;
       this.gender=gender;
       this.value=value;
       this.numberOfSell=numberOfSell;
    }

    

   
//To String
    @Override
    public String toString() {
        
        return "Song [name: "+super.getName()  +" album=" + album + ", gender=" + gender + ", value=" + value + ", numberOfSell=" + numberOfSell
                +"]"+"\n";
    }



 //Get and Set
    public String getAlbum() {
        return album;
    }

    public void setAlbum(String album) {
        this.album = album;
    }

    public TypeGender getGender() {
        return gender;
    }

    public void setGender(TypeGender gender) {
        this.gender = gender;
    }


    public int getNumberOfSell() {
        return numberOfSell;
    }

    public void setNumberOfSell(int numberOfSell) {
        this.numberOfSell = numberOfSell;
    }




    public int getValue() {
        return value;
    }




    public void setValue(int value) {
        this.value = value;
    }






  
}