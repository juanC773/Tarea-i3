package model;
import java.util.ArrayList;
public class PlayList {

 

    //Atributtes
    private String name;
    private String id;
    private  ArrayList<Audio>audios;
    




    /**
     * name: Playlist
      * The builder.
      * @param name Contains the name of the playlist.
      * @param id Contains the identifier of the playlist.
     */
    public PlayList(String name, String id) {

        this.name=name;
        this.id=id;
       
       
        audios= new ArrayList<Audio>();
      
    }


    /**
      * name:audiosResume
      * Print the audios of a certain playlist
      * @return Returns a String with the songs
      * (Playlist must exist)
      */
    public String audiosResume(){
		String msj = "The audios on this playlist are: \n";
		int counter = 0;
        int k=0;
		for (int i = 0; i < audios.size(); i++) {
            k++;
			msj += k+". "+audios.get(i).getName()+"\n";
			counter++;
		}
		if(counter == 0){
			msj = "There are no audios in this playlist";
		}
		return msj;
	}


    /**
      * name: addAudio
      * add audio
      * @param audioData contains the Audio object to add
      * @return Returns a boolean that indicates if it was executed correctly
      */
    public boolean addAudio(Audio audioData) {
        audios.add(audioData);
        return true;
    }

    /**
      * name: removeAudio
      * remove audio
      * @param audioSelect Contains the index indicating which audio to remove
      * @return Returns a boolean indicating whether or not the audio has been successfully removed
      */
    public boolean removeAudio(int audioSelect) {
        audios.remove(audioSelect);
        return true;
    }
     

  
     //To String 
    @Override
   
    public String toString() {
        return "PlayList [name=" + name + "]";
    }



  //Get and Set
    public String getName() {
        return name;
    }


    public void setName(String name) {
        this.name = name;
    }


    public String getId() {
        return id;
    }


    public void setId(String id) {
        this.id = id;
    }



    public ArrayList<Audio> getAudios() {
        return audios;
    }



    public void setAudios(ArrayList<Audio> audios) {
        this.audios = audios;
    }






   


    
}