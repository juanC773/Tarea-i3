package model;

import java.time.LocalDate;
import java.util.ArrayList;

public class Standard extends Consumer implements Playable {

    /*acceso al catalogo de audio.
     *hasta 20 listas de reproducción.
     *hasta 100 canciones
     */

    //Relations
    private Song[] mySongs;
	private PlayList[] myPlayL;
    private ArrayList<Song> mySongsListened;
    private ArrayList<Podcast> myPodcastListened;

    /**
     *  name: advertising
      * generate ads
      * @param index Contains the index which indicates which ad will be displayed
      * @return Returns a String with the ad
      */
    public String ads(int index){
        String message="";
        String advertising[]= new String[3];
        advertising[0]="Nike - Just Do It.";
        advertising[1]="Coca-Cola - Open Happiness.";
        advertising[2]="M&Ms - Melts in Your Mouth, Not in Your Hands";
        if(index==1){
            message+=advertising[0];
        }
        else if(index==2){
            message+=advertising[1];
        }
        else if(index==3){
            message+=advertising[2];
        }
        return message;
    }

    
    int counterSpam=0;

    //It does not generate javadoc :(

    /*
     * name: playAudio
      * Play an audio
      * parag@ positionAudio (Contains the index indicating which audio should be played)
      * parag@ audios (Contains the audio catalog)
      * return Returns the String that indicates the reproduction of the audio or not
      */
     

    public String playAudio(int positionAudio, ArrayList<Audio> audios) {
        
        String msg = "The audio doesn't exist";
       
        for(int i=0; i<audios.size(); i++){
                int index = (int)(Math.random()*(3-1))+1;
                if(audios.get(positionAudio) instanceof Song){
                    
                    counterSpam++;
                    if(counterSpam%2==0){
                        msg = "Reproducing\n" + audios.get(positionAudio).getName() + "...\n" + "Sponsored by: " + ads(index);
                    }else {
                        msg = "Reproducing\n" + audios.get(positionAudio).getName()+".....";
                    }
                }
                else if(audios.get(positionAudio) instanceof Podcast){
                    msg= "Sponsored by: "+ads(index)+" Reproducing..."+" \n"+audios.get(positionAudio).getName()+" ...";
                }
            }
            
        return msg;
    }
   



    /**
      * name: Standard
      * The builder.
      * @param nicknameName Contains the nickname of the standard user
      * @param document Contains the standard user document
      * @param date Contains the date
     */
    public Standard(String nickName, String document, LocalDate date) {
        super(nickName, document, date);

        this.mySongs = new Song[100];
		this.myPlayL = new PlayList[20];
        this.mySongsListened= new ArrayList<Song>();
        this.myPodcastListened= new ArrayList<Podcast>();

    }

    /**
      * name: addAudioToPlaylist
      * @param index Contains the index that indicates the specific playlist to which you want to add the audio
      * @param audioData Contains the audio to be added
      * @return Returns a boolean indicating whether or not it was added
      */
    public boolean addAudioToPlaylist(int index, Audio audioData) {
        if (objPlayList.size() < 20) {
            objPlayList.get(index).addAudio(audioData);
            return true;
        }
        return false;
    }

   //Get and set

   

   
    public Song[] getMySongs() {
        return mySongs;
    }



    public ArrayList<Song> getMySongsListened() {
        return mySongsListened;
    }




    public void setMySongsListened(ArrayList<Song> mySongsListened) {
        this.mySongsListened = mySongsListened;
    }




    public int getCounterSpam() {
        return counterSpam;
    }




    public void setCounterSpam(int counterSpam) {
        this.counterSpam = counterSpam;
    }




    public void setMySongs(Song[] mySongs) {
        this.mySongs = mySongs;
    }



    public PlayList[] getMyPlayL() {
        return myPlayL;
    }



    public void setMyPlayL(PlayList[] myPlayL) {
        this.myPlayL = myPlayL;
    }




    public ArrayList<Podcast> getMyPodcastListened() {
        return myPodcastListened;
    }




    public void setMyPodcastListened(ArrayList<Podcast> myPodcastListened) {
        this.myPodcastListened = myPodcastListened;
    }

    
}