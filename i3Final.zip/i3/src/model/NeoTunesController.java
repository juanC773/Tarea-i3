package model;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Locale.Category;

public class NeoTunesController {

    // Relations
    private ArrayList<User> users;
    private ArrayList<Audio> catalogue;
    private ArrayList<Song> catalogueSongs;
    private ArrayList<Podcast> cataloguePodcast;

    // Constructor.
    public NeoTunesController() {
        users = new ArrayList<User>();
        catalogue = new ArrayList<Audio>();
        catalogueSongs = new ArrayList<Song>();
        cataloguePodcast = new ArrayList<Podcast>();

    }

    /**
     * name: searchUser.
     * Search the users document to verify that there is no one with the same
     * document.
     * 
     * @param document contains the user's document.
     * @return Returns a boolean to confirm if the search ID exists or not.
     */
    public boolean searchUser(String document) {
        boolean exist = true;

        for (int i = 0; i < users.size() && !exist; i++) {
            if (users.get(i).getDocument().equals(document))
                exist = false;
        }

        return exist;
    }

    /**
     * name: searchObjUser.
     * With the nickname, search for a user
     * 
     * @param nicknameName Contains the nickname to search for
     * @return Returns an object of type user
     */
    public User searchObjUser(String nickName) {
        User userOBJ = null;
        boolean exist = false;

        for (int i = 0; i < users.size() && !exist; i++) {
            if (users.get(i).getNickName().equals(nickName)) {
                userOBJ = users.get(i);
                exist = true;
            }
        }

        return userOBJ;
    }

    /**
     * name: positionUser
     * It has the functionality to find the position of a user.
     * 
     * @param nicknameName Contains the nickname of the user
     * @return returns an iterator, which indicates the position.
     *         (There must be registered users).
     */
    public int positionUser(String nickName) {
        boolean exist = false;
        int position = 0;

        for (int i = 0; i < users.size() && !exist; i++) {
            if (users.get(i).getNickName().equals(nickName)) {
                User userOBJ = users.get(i);
                exist = true;
                position = i;
            }
        }
        return position;
    }

    /**
     * name: searchNNickName
     * Search for a user's nickname to verify if it exists or not
     * 
     * @param nicknameName Contains the nickname to search for.
     * @return Returns a boolean which indicates whether the user exists or not.
     */
    public boolean searchNickname(String nickName) {
        boolean exist = false;

        for (int i = 0; i < users.size() && !exist; i++) {
            if (users.get(i).getNickName().equals(nickName)) {
                exist = true;
            }
        }

        return exist;
    }

    /**
     * name: searchAudio
     * check if an audio already exists or not
     * 
     * @param name Contains the name of the audio to search for
     * @return Returns a boolean which indicates whether the audio in question
     *         exists or not *
     */
    public boolean searchAudio(String name) {
        boolean exist = true;

        for (int i = 0; i < users.size() && !exist; i++) {
            if (catalogue.get(i).getName().equals(name)) {
                exist = false;

            }
        }

        return exist;
    }

    /**
     * name: addUser
     * Create standard type users.
     * 
     * @param nickName contains the nickname of the consuming user.
     * @param document contains the consumer user's document.
     * @param date     contains the binding date.
     * @param option   contains the option, which indicates whether it is a standard
     *                 or premium type user.
     * @return Returns a message indicating whether the consumer user was created
     *         correctly or not.
     */
    public String addUser(String nickName, String document, LocalDate date, int option) {

        String message = "";
        boolean confirm = searchUser(document);

        if (confirm & option == 1) {
            Standard objStandard = new Standard(nickName, document, date);
            users.add(objStandard);
            message = "The standard user was created successfully.";
        } else if (confirm & option == 2) {
            Premium objPremium = new Premium(nickName, document, date);
            users.add(objPremium);
            message = "The premium user was created successfully.";
        } else if (!confirm) {
            message = "It could not be created because there is already someone with this same document.";
        }
        return message;
    }

    /**
     * name: addUser.
     * Create and add producer users.
     * 
     * @param nickName         contains the nickname of the producer user.
     * @param document         contains the document of the producer user.
     * @param date             contains the date.
     * @param name             contains the name of the producer.
     * @param imageProducerUrl contains de url of the image.
     * @param option           contains the option, which indicates whether it is a
     *                         artist or content creater type user.
     * @return Returns a message indicating whether the producer user was created
     *         correctly or not
     */
    public String addUser(String nickName, String document, LocalDate date, String name, String imageProducerUrl,
            int option) {
        String message = "";

        boolean confirm = searchUser(document);

        if (confirm & option == 1) {
            Artist objArtist = new Artist(nickName, document, date, name, imageProducerUrl);
            users.add(objArtist);
            message = "The Artist user was created successfully.";
        } else if (confirm & option == 2) {
            ContentCreator objContentCreator = new ContentCreator(nickName, document, date, name, imageProducerUrl);
            users.add(objContentCreator);
            message = "The creator user was created successfully.";
        } else if (!confirm) {
            message = "It could not be created because there is already someone with this same document.";
        }
        return message;
    }

    /**
     * name: searchPlaylist
     * Search a playlist
     * 
     * @param nameUser     Contains the name of the user
     * @param namePlaylist Contains the name of the playlist to compare
     * @return Returns a boolean to know if the playlist exists or not
     */
    public boolean searchPlaylist(String nameUser, String namePlaylist) {

        User objUser = searchObjUser(nameUser);

        boolean exist = false;

        if (objUser != null) {
            if (objUser instanceof Standard) {

                Standard standardObj = (Standard) objUser;

                for (int i = 0; i < 20 && !exist; i++) {
                    if (standardObj.getMyPlayL()[i] != null
                            && standardObj.getMyPlayL()[i].getName().equalsIgnoreCase(namePlaylist)) {

                        exist = true;

                    }
                }
            }

            if (objUser instanceof Premium) {

                Premium premiumObj = (Premium) objUser;

                for (int i = 0; i < premiumObj.getMyPlayLists().size() && !exist; i++) {
                    if (premiumObj.getMyPlayLists().get(i).getName().equalsIgnoreCase(namePlaylist)) {
                        exist = true;

                    }
                }
            }

        }
        System.out.println(exist);
        return exist;
    }

    /**
     * name: addSong
     * create and add the songs.
     * 
     * @param name                 contains the name of the song.
     * @param urlCover             contains the url of the song cover
     * @param duration             contains the duration of the song
     * @param numberOfReproduction Contains the number of reproductions of the song
     * @param album                Contains the album of the song.
     * @param option               Contains the option of the genre of the song.
     * @param value                Contains the cost of the song.
     * @param numberOfSell         Contains the number of sales.
     * @return Returns if the song could be created correctly or not.
     */

    public String addAudio(String nickNameArtist, String name, String urlCover, double duration,
            int numberOfReproduction, String album, int option, int value, int numberOfSell) {
        String messsage = "The song was created correctly";

        TypeGender gender = null;
        if (option == 1) {
            gender = TypeGender.ROCK;

        } else if (option == 2) {
            gender = TypeGender.POP;

        } else if (option == 3) {
            gender = TypeGender.TRAP;

        } else if (option == 4) {
            gender = TypeGender.HOUSE;
        }

        User userOBJ = null;
        userOBJ = searchObjUser(nickNameArtist);

        if (userOBJ instanceof Artist) {
            boolean existAudio = searchAudio(name);
            if (!existAudio) {

                messsage = "The song already exist";
            } else {
                Song objSong = new Song(name, album, gender, urlCover, duration, value, numberOfReproduction,
                        numberOfSell);

                Artist artistOBJ = (Artist) userOBJ;
                artistOBJ.getMySongs().add(objSong);
                catalogue.add(objSong);
                catalogueSongs.add(objSong);

            }

        }

        return messsage;
    }

    /**
     * name: add Audio
     * Create and add podcasts.
     * 
     * @param name                contains the name of the podcast
     * @param description         contains the description of the podcast.
     * @param option              contains the option for the podcast category.
     * @param urlImage            Contains the podcast cover art url.
     * @param duration            Contains the duration of the podcast.
     * @param numberOfReprodution Contains the number of reproductions of the
     *                            podcast.
     * @return Returns whether the podcast was created successfully or not.
     */
    public String addAudio(String nickNameCreator, String name, String description, int option, String urlImage,
            double duration,
            int numberOfReprodution) {
        String messsage = "The podcast was created correctly";

        TypeCategory category = null;
        if (option == 1) {
            category = TypeCategory.POLITIC;

        } else if (option == 2) {
            category = TypeCategory.ENTERTAIMENT;

        } else if (option == 3) {
            category = TypeCategory.VIDEOGAME;

        } else if (option == 4) {
            category = TypeCategory.FASHION;
        }

        boolean exist = searchAudio(name);
        User userOBJ = null;
        userOBJ = searchObjUser(nickNameCreator);

        if (exist && userOBJ instanceof ContentCreator) {

            Podcast objPodcast = new Podcast(name, description, category, urlImage, duration, numberOfReprodution);
            catalogue.add(objPodcast);
            cataloguePodcast.add(objPodcast);
            ContentCreator userCreator = (ContentCreator) userOBJ;
            userCreator.getMyPodcast().add(objPodcast);

        } else {
            messsage = "Couldn't create the podcast because one with the same name already exists";
        }

        return messsage;
    }

    /**
     * name: generateRandom
     * Generates a random number from 1-9
     * 
     * @return Returns the random number
     */
    public int generateRandom() {

        int number = (int) (Math.random() * (8 + 1) + 1);

        return number;
    }

    /**
     * name: generateMatriz
     * generates an array
     * 
     * @return Returns a 6x6 matriz
     */

    public int[][] generateMatriz() {

        int matriz[][] = new int[6][6];

        // Here the random method is used to fill the array.
        for (int i = 0; i < 6; i++) {
            for (int j = 0; j < 6; j++) {
                matriz[i][j] = generateRandom();
            }
        }

        return matriz;
    }

    /**
     * name: generateIdentifier
     * Generate playlist identifier
     * Option @param Contains the option of the playlist type
     * 
     * @param array Contains the array in another method
     * @return Returns the playlist identifier
     *         (Requires an array to exist)
     */

    public String generateIdentifier(int option, int[][] matriz) {

        String code = "";

        switch (option) {
            case 1:
                for (int i = matriz.length; i > 0; i--) {
                    code += matriz[i - 1][0];
                }
                for (int i = 1, j = 1; i < matriz.length - 1; i++, j++) {
                    code += matriz[i][j];
                }
                for (int i = matriz.length; i > 0; i--) {
                    code += matriz[i - 1][matriz[0].length - 1];
                }
                break;

            case 2:
                for (int j = 0; j < matriz.length - 4; j++) {
                    code += matriz[0][j];
                }
                for (int i = 0; i < matriz.length; i++) {
                    code += matriz[i][2];
                }
                for (int i = matriz.length; i > 0; i--) {
                    code += matriz[i - 1][3];
                }
                for (int j = matriz.length - 2; j < matriz.length; j++) {
                    code += matriz[0][j];
                }
                break;
            case 3:
                for (int i = 5; i >= 0; i--) {
                    for (int j = 5; j >= 0; j--) {
                        int sum = i + j;
                        if (sum % 2 != 0) {
                            if (sum != 1) {
                                code += matriz[i][j] + " ";
                            }
                        }
                    }
                }
                break;
        }
        return code;
    }

    /**
     * name: createPlaylist
     * Create the playlist
     * 
     * @param optionOfConsumer     Contains the option of the consumer user type
     * @param nicknameNameToSearch Contains the consumer's nickname
     * @param namePlaylist         Contains the name of the new playlist
     * @param option               Contains the playlist type option
     * @return
     *         (Requires other methods such as the identifier or search for a user)
     */
    public String createPlaylist(int optionOfConsumer, String nickNameToSearch, String namePlaylist,
            int optionPlaylist) {
        String message = "";
        User userObj = searchObjUser(nickNameToSearch);
        if (userObj != null) {
            int matriz[][] = generateMatriz();
            String id = generateIdentifier(optionPlaylist, matriz);
            if (optionOfConsumer == 1) {
                PlayList objPlayList = new PlayList(namePlaylist, id);
                Standard standardObj = (Standard) userObj;
                boolean stop = false;

                for (int i = 0; i < 20 && !stop; i++) {

                    if (standardObj.getMyPlayL()[i] == null) {

                        standardObj.getMyPlayL()[i] = objPlayList;

                        stop = true;

                    }
                }
                message = "the Standard user, his playlist was created correctly";
            }

            if (optionOfConsumer == 2) {

                PlayList objPlayList = new PlayList(namePlaylist, id);
                Premium premiumObj = (Premium) userObj;
                premiumObj.getMyPlayLists().add(objPlayList);

                message = "to the premium user, his playlist was created correctly";
            }

        } else {
            message = "The playlist could not be created because the user does not exist";
        }

        return message;
    }

    /**
     * Name: audiosOfAPlaylist
     * Print the audios of a certain playlist
     * 
     * @param index Contains the position of the chosen playlist
     * @param name  Contains the name of the user
     * @return Returns a String that shows the user the audios of the playlist.
     *         (Playlist must exist before using the method).
     */
    public String audiosOfAplaylist(int index, String name) {
        String message = "";
        User user = searchObjUser(name);

        if (user instanceof Standard && user != null) {

            Standard userStandard = (Standard) user;
            message += userStandard.getMyPlayL()[index - 1].audiosResume();

        } else if (user instanceof Premium && user != null) {
            Premium userPremium = (Premium) user;
            message += userPremium.getMyPlayLists().get(index - 1).audiosResume();
        }

        return message;
    }

    /**
     * name: editPlaylist
     * 
     * @param option         Contiene la opción de editar playlist(añadir canción o
     *                       eliminarla)
     * @param optionPlaylist Contiene la playlist que se quiere editar
     * @param optionSong     Contiene la canción que se quiere editar
     * @param nameUser       Contiene el nombre del dueño de la playlist
     * @return Retorna un mensaje indicando que la playlist fue editada
     *         (Deben existir artistas o creadores de contenido, usuarios, canciones
     *         o podcast)
     */
    public String editPlaylist(int option, int optionPlaylist, int optionSong, String nameUser) {
        String message = "";
        optionPlaylist--;
        User objUser = searchObjUser(nameUser);
        Audio objAudio = catalogue.get(optionPlaylist);
        int position = positionUser(nameUser);

        if (objUser instanceof Standard && objUser != null && option == 1) {

            Standard userStandard = (Standard) objUser;
            userStandard.getMyPlayL()[optionPlaylist].addAudio(objAudio);

            message = "The song has been added for: " + userStandard.getNickName() + " , is a standard user";
        } else if (objUser instanceof Premium && objUser != null && option == 1) {
            Premium userPremium = (Premium) objUser;
            userPremium.getMyPlayLists().get(optionPlaylist).addAudio(objAudio);

            message = "The song has been added for: " + userPremium.getNickName() + " , is a premium user";
        }

        else if (objUser instanceof Standard && objUser != null && option == 2) {
            Standard userStandard = (Standard) objUser;
            userStandard.getMyPlayL()[optionPlaylist].removeAudio(optionSong - 1);

            message = "The song has been removed for the user: " + userStandard.getNickName()
                    + " , is a standard user";
        } else if (objUser instanceof Premium && objUser != null && option == 2) {
            Premium userPremium = (Premium) objUser;
            userPremium.getMyPlayLists().get(optionPlaylist).removeAudio(optionSong - 1);

            message = "The song has been removed for the user: " + userPremium.getNickName()+ " , is a premium user";
        }

        return message;
    }

    /**
     * name: printCatalogue
     * print the songs and podcasts
     * 
     * @return return a message with the songs and podcasts
     *         (there have to be songs or podcast)
     */
    public String printCatalogue() {
        String message = "The songs and podcasts of the catalogue are: \n";
        int k = 0;
        for (int i = 0; i < catalogue.size(); i++) {
            k++;
            message += k + ". " + catalogue.get(i).toString();

        }
        return message;
    }

    /**
     * name: printAllSong
     * print the songs
     * 
     * @return return a message with the songs
     *         (there have to be songs)
     */
    public String printAllSong() {
        String message = "";
        int k = 0;

        for (int i = 0; i < catalogueSongs.size(); i++) {
            k++;
            message += k + ". " + catalogueSongs.get(i).toString();

        }
        return message;
    }

    /**
     * name: printPlaylist
     * Print all the playlists of a user
     * 
     * @param nameUser Contains the name of the user
     * @return Returns a String with the user's playlists
     *         (There must be users with created playlists).
     */
    public String printPlaylist(String nameUser) {
        String message = "The playlists of the user are: \n";

        User user = searchObjUser(nameUser);

        if (user instanceof Standard && user != null) {

            Standard userStandard = (Standard) user;
            int k = 0;
            for (int i = 0; i < 20 && userStandard.getMyPlayL()[i] != null; i++) {
                k++;
                message += k + ". " + userStandard.getMyPlayL()[i].toString();
            }
        } else if (user instanceof Premium && user != null) {

            Premium userPremium = (Premium) user;

            int l = 0;

            for (int i = 0; i < userPremium.getMyPlayLists().size(); i++) {
                l++;
                message += l + ". " + userPremium.getMyPlayLists().get(i).toString();
            }
        } else {
            message = "The user doesn't exist";
        }
        return message;
    }

    /**
     * name: buyASong
     * Buy a song from the catalog
     * 
     * @param SongToBuy Contains the song to buy.
     * @param nameUser  Contains the name of the user.
     * @return Returns a message indicating whether the song could be purchased or
     *         not.
     *         There must be songs.
     */
    public String buyASong(int SongToBuy, String nameUser) {

        String message = "Couldn't make the purchase";
        Song songBought = catalogueSongs.get(SongToBuy - 1);

        String nameSong = songBought.getName();
        User user = searchObjUser(nameUser);
        if (user != null && user instanceof Standard) {

            Standard userStandard = (Standard) user;
            boolean stop = false;
            for (int i = 0; i < 100 && !stop; i++) {
                if (userStandard.getMySongs()[i] == null) {
                    userStandard.getMySongs()[i] = songBought;
                    stop = true;
                    message = "the purchase of the song " + nameSong + " for the standard user has been successful";

                    int numberToChange = catalogueSongs.get(SongToBuy - 1).getNumberOfSell();
                    numberToChange++;
                    catalogueSongs.get(SongToBuy - 1).setNumberOfSell(numberToChange);
                }
            }
        } else if (user != null && user instanceof Premium) {
            Premium userPremium = (Premium) user;
            userPremium.getMySongs().add(songBought);
            message = "the purchase of the song " + nameSong + " for the premium user has been successful";

            int numberToChange = catalogueSongs.get(SongToBuy - 1).getNumberOfSell();
            numberToChange++;
            catalogueSongs.get(SongToBuy - 1).setNumberOfSell(numberToChange);
        }

        return message;
    }

    /**
     * name: playAudio
     * indicates to the type of user which audio to play
     * 
     * @param nameUser      Contains the name of the user.
     * @param audioSelected Contains the index of the audio to play
     * @return Returns a message with the played audio
     *         (Requires another method which plays the audio).
     */
    public String reproduceAudio(String nameUser, int audioSelected) {
        String message = "";
        audioSelected = audioSelected - 1;
        Audio objAudio = catalogue.get(audioSelected);

        User objUser = searchObjUser(nameUser);

        if (catalogue.get(audioSelected) instanceof Song && objUser instanceof Standard) {

            Standard objStandard = (Standard) objUser;
            Song objSong = (Song) objAudio;
            message = objStandard.playAudio(audioSelected, catalogue);

            // Total reproductions of the song
            int numberToChange = catalogue.get(audioSelected).getNumberOfReproduction();
            numberToChange++;
            catalogue.get(audioSelected).setNumberOfReproduction(numberToChange);

            // Total reproductions of a genre
            objStandard.getMySongsListened().add(objSong);

        } else if (objUser instanceof Premium && catalogue.get(audioSelected) instanceof Song) {
            Premium objPremium = (Premium) objUser;
            Song objSong = (Song) objAudio;
            message = objPremium.playAudio(audioSelected, catalogue);

            // Total reproductions of the song
            int numberToChange = catalogue.get(audioSelected).getNumberOfReproduction();
            numberToChange++;
            catalogue.get(audioSelected).setNumberOfReproduction(numberToChange);

            // Total reproductions of a genre
            objPremium.getMySongsListened().add(objSong);

        } else if (catalogue.get(audioSelected) instanceof Podcast && objUser instanceof Standard) {
            Standard objStandard = (Standard) objUser;
            Podcast objPodcast = (Podcast) objAudio;
            message = objStandard.playAudio(audioSelected, catalogue);

            // Total reproductions of the song
            int numberToChange = catalogue.get(audioSelected).getNumberOfReproduction();
            numberToChange++;
            catalogue.get(audioSelected).setNumberOfReproduction(numberToChange);

            // Total reproductions of a category
            objStandard.getMyPodcastListened().add(objPodcast);
        }

        else if (catalogue.get(audioSelected) instanceof Podcast && objUser instanceof Premium) {
            Premium objPremium = (Premium) objUser;
            Podcast objPodcast = (Podcast) objAudio;
            message = objPremium.playAudio(audioSelected, catalogue);

            // Total reproductions of the song
            int numberToChange = catalogue.get(audioSelected).getNumberOfReproduction();
            numberToChange++;
            catalogue.get(audioSelected).setNumberOfReproduction(numberToChange);

            // Total reproductions of a category
            objPremium.getMyPodcastListened().add(objPodcast);
        }

        return message;
    }

    /**
     * name: sharePlaylist
     * 
     * @param nameUser       Contains the name of the user
     * @param optionPlaylist Contains the position of the playlist
     * @return Returns a message with the array and the id of the playlist
     *         (There must be registered users and playlist).
     */
    public String sharePlaylist(String nameUser, int optionPlaylist) {

        String message = "The option is invalid";
        User objUser = searchObjUser(nameUser);

        if (objUser instanceof Standard) {
            Standard objStandard = (Standard) objUser;
            int matriz[][] = generateMatriz();

            message = "The name of the playlist is: " + objStandard.getMyPlayL()[optionPlaylist - 1].getName()
                    + " and the id is :" + objStandard.getMyPlayL()[optionPlaylist - 1].getId() + "\n\nMatriz: \n"
                    + printMatriz(matriz);

        } else if (objUser instanceof Premium) {
            Premium objPremium = (Premium) objUser;
            int matriz[][] = generateMatriz();
            message = "Then name of the playlist is: " + objPremium.getMyPlayLists().get(optionPlaylist - 1).getName()
                    + " and the id is :" + objPremium.getMyPlayLists().get(optionPlaylist - 1).getId()
                    + "\n\nMatriz: \n" + printMatriz(matriz);
        }
        return message;

    }

    /**
     * name :printMatrix
     * Prints a matrix
     * 
     * @param matrix Contains the matrix which you want to print
     * @return Returns a String with the matrix printed
     */
    public String printMatriz(int[][] matriz) {
        String msg = "";
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz.length; j++) {
                msg += (matriz[i][j] + " ");
            }
            msg += "\n";
        }
        return msg;
    }

    /**
     * name: totalReproduction
     * 
     * @return returns an integer more a int that indicates the total reproductions
     *         of the platform
     *         (There must be audio)
     */
    public String totalReproduction() {
        String message = "The total reproductions of the plataform are: ";
        int totalReproduction = 0;
        for (int i = 0; i < catalogue.size(); i++) {

            totalReproduction += catalogue.get(i).getNumberOfReproduction();
        }
        return message + totalReproduction;
    }

    /**
     * name: bestSellingSong
     * 
     * @return Returns a message with the most sold song and the profits it
     *         generated
     *         (There must be audio)
     */
    public String bestSellingSong() {
        String message = "";

        for (int i = 0; i < catalogueSongs.size(); i++) {
            int aux = Integer.MIN_VALUE;
            if (catalogueSongs.get(i).getNumberOfSell() > aux) {
                aux = catalogueSongs.get(i).getNumberOfSell();
                int position = i;

                int stonks = aux * catalogueSongs.get(position).getValue();

                message += "The song more sell is: " + catalogueSongs.get(position).getName() + " with earnings of: "
                        + stonks + "$";

            }
        }

        return message;
    }
    
    /**
      * name: mostListenedGenre
      * It informs the user which is the most listened to song genre for a user or the entire platform.
      * @param option Contains the option to display the most listened to genre for the entire platform or a single user
      * @param nameUser Contains the name of the user
      * @return Returns a message with the most played song genre
      * (There must be registered users, artists and songs)
      */
    public String mostListenedGenre(int option, String nameUser) {
        String message = "";
        int totalReproductionHouse = 0;
        int totalReproductionPop = 0;
        int totalReproductionRock = 0;
        int totalReproductionTrap = 0;

        User objUser = searchObjUser(nameUser);

        if (option == 1) {
            for (int i = 0; i < catalogueSongs.size(); i++) {
                if (catalogueSongs.get(i).getGender() == TypeGender.HOUSE) {
                    totalReproductionHouse += catalogueSongs.get(i).getNumberOfReproduction();
                } else if (catalogueSongs.get(i).getGender() == TypeGender.POP) {
                    totalReproductionPop += catalogueSongs.get(i).getNumberOfReproduction();
                } else if (catalogueSongs.get(i).getGender() == TypeGender.ROCK) {
                    totalReproductionRock += catalogueSongs.get(i).getNumberOfReproduction();
                } else if (catalogueSongs.get(i).getGender() == TypeGender.TRAP) {
                    totalReproductionTrap += catalogueSongs.get(i).getNumberOfReproduction();
                }
            }

            if (totalReproductionHouse > totalReproductionPop && totalReproductionHouse > totalReproductionRock
                    && totalReproductionHouse > totalReproductionTrap && option == 1) {
                message = "The genre most listened is: House with " + totalReproductionHouse + " reprodutions";
            } else if (totalReproductionPop > totalReproductionHouse && totalReproductionPop > totalReproductionRock
                    && totalReproductionPop > totalReproductionTrap && option == 1) {
                message = "The genre most listened is: Pop with " + totalReproductionPop + " reprodutions";
            } else if (totalReproductionRock > totalReproductionHouse && totalReproductionRock > totalReproductionPop
                    && totalReproductionRock > totalReproductionTrap && option == 1) {
                message = "The genre most listened is: rock with " + totalReproductionRock + " reprodutions";
            } else if (totalReproductionTrap > totalReproductionHouse && totalReproductionTrap > totalReproductionPop
                    && totalReproductionTrap > totalReproductionRock && option == 1) {
                message = "The genre most listened is: Trap with " + totalReproductionTrap + " reprodutions";
            }
        } else if (option == 2) {

            if (objUser instanceof Standard) {
                Standard objStandard = (Standard) objUser;

                for (int i = 0; i < objStandard.getMySongsListened().size(); i++) {
                    if (objStandard.getMySongsListened().get(i).getGender() == TypeGender.HOUSE) {
                        totalReproductionHouse += objStandard.getMySongsListened().get(i).getNumberOfReproduction();
                    } else if (objStandard.getMySongsListened().get(i).getGender() == TypeGender.POP) {
                        totalReproductionPop += objStandard.getMySongsListened().get(i).getNumberOfReproduction();

                    } else if (objStandard.getMySongsListened().get(i).getGender() == TypeGender.ROCK) {
                        totalReproductionRock += objStandard.getMySongsListened().get(i).getNumberOfReproduction();

                    } else if (objStandard.getMySongsListened().get(i).getGender() == TypeGender.TRAP) {
                        totalReproductionTrap += objStandard.getMySongsListened().get(i).getNumberOfReproduction();

                    }
                }
            } else if (objUser instanceof Premium) {
                Premium objPremium = (Premium) objUser;
                for (int i = 0; i < objPremium.getMySongs().size(); i++) {
                    if (objPremium.getMySongs().get(i).getGender() == TypeGender.HOUSE) {
                        totalReproductionHouse += objPremium.getMySongs().get(i).getNumberOfReproduction();
                    } else if (objPremium.getMySongs().get(i).getGender() == TypeGender.POP) {
                        totalReproductionPop += objPremium.getMySongs().get(i).getNumberOfReproduction();
                    } else if (objPremium.getMySongs().get(i).getGender() == TypeGender.ROCK) {
                        totalReproductionRock += objPremium.getMySongs().get(i).getNumberOfReproduction();
                    } else if (objPremium.getMySongs().get(i).getGender() == TypeGender.TRAP) {
                        totalReproductionTrap += objPremium.getMySongs().get(i).getNumberOfReproduction();
                    }
                }
            }
        }

        if (totalReproductionHouse > totalReproductionPop && totalReproductionHouse > totalReproductionRock
                && totalReproductionHouse > totalReproductionTrap && option == 2) {
            message = "The genre most listened of: " + objUser.getNickName() + " is House with "
                    + totalReproductionHouse + " reprodutions";
        } else if (totalReproductionPop > totalReproductionHouse && totalReproductionPop > totalReproductionRock
                && totalReproductionPop > totalReproductionTrap && option == 2) {
            message = "The genre most listened of: " + objUser.getNickName() + " is Pop with " + totalReproductionPop
                    + " reprodutions";
        } else if (totalReproductionRock > totalReproductionHouse && totalReproductionRock > totalReproductionPop
                && totalReproductionRock > totalReproductionTrap && option == 2) {
            message = "The genre most listened of: " + objUser.getNickName() + " is rock with " + totalReproductionRock
                    + " reprodutions";
        } else if (totalReproductionTrap > totalReproductionHouse && totalReproductionTrap > totalReproductionPop
                && totalReproductionTrap > totalReproductionRock && option == 2) {
            message = "The genre most listened of: " + objUser.getNickName() + "is Trap with " + totalReproductionTrap
                    + " reprodutions";
        }

        return message;
    }

    /**
     * name: mostListenedPodcast
      * Shows the type of podcast most played for a user or the entire platform on the screen
      * @param option contains the option to display the most played podcast for a user or the entire platform
      * @param nameUser Contains the username
      * @return Returns the most played podcast type
      * (There must be registered users and podcast)
      */
    public String mostListenedPodcast(int option, String nameUser) {
        String message = "";
        int totalReproductionEntertaiment = 0;
        int totalReproductionFashion = 0;
        int totalReproductionPolitic = 0;
        int totalReproductionVideoGame = 0;

        User objUser = searchObjUser(nameUser);

        if (option == 1) {
            for (int i = 0; i < cataloguePodcast.size(); i++) {

                if (cataloguePodcast.get(i).getCategory() == TypeCategory.ENTERTAIMENT) {
                    totalReproductionEntertaiment += cataloguePodcast.get(i).getNumberOfReproduction();
                } else if (cataloguePodcast.get(i).getCategory() == TypeCategory.FASHION) {
                    totalReproductionFashion += cataloguePodcast.get(i).getNumberOfReproduction();
                } else if (cataloguePodcast.get(i).getCategory() == TypeCategory.POLITIC) {
                    totalReproductionPolitic += cataloguePodcast.get(i).getNumberOfReproduction();
                } else if (cataloguePodcast.get(i).getCategory() == TypeCategory.VIDEOGAME) {
                    totalReproductionVideoGame += cataloguePodcast.get(i).getNumberOfReproduction();

                }
            }

            if (totalReproductionEntertaiment > totalReproductionFashion
                    && totalReproductionEntertaiment > totalReproductionPolitic
                    && totalReproductionEntertaiment > totalReproductionVideoGame && option == 1) {
                message = "The category most listened is: entertaiment with " + totalReproductionEntertaiment
                        + " reprodutions";
            } else if (totalReproductionFashion > totalReproductionEntertaiment
                    && totalReproductionFashion > totalReproductionPolitic
                    && totalReproductionFashion > totalReproductionVideoGame && option == 1) {
                message = "The category most listened is: fashion with " + totalReproductionFashion + " reprodutions";
            } else if (totalReproductionPolitic > totalReproductionEntertaiment
                    && totalReproductionPolitic > totalReproductionFashion
                    && totalReproductionPolitic > totalReproductionVideoGame && option == 1) {
                message = "The category most listened is: politic with " + totalReproductionPolitic + " reprodutions";
            } else if (totalReproductionVideoGame > totalReproductionEntertaiment
                    && totalReproductionVideoGame > totalReproductionFashion
                    && totalReproductionVideoGame > totalReproductionPolitic && option == 1) {
                message = "The category most listened is: videogame with " + totalReproductionVideoGame
                        + " reprodutions";
            }

        } else if (option == 2) {
            if (objUser instanceof Standard) {
                Standard objStandard = (Standard) objUser;

                for (int i = 0; i < objStandard.getMyPodcastListened().size(); i++) {
                    if (objStandard.getMyPodcastListened().get(i).getCategory() == TypeCategory.ENTERTAIMENT) {
                        totalReproductionEntertaiment += objStandard.getMyPodcastListened().get(i)
                                .getNumberOfReproduction();
                    } else if (objStandard.getMyPodcastListened().get(i).getCategory() == TypeCategory.FASHION) {
                        totalReproductionFashion += objStandard.getMyPodcastListened().get(i).getNumberOfReproduction();

                    } else if (objStandard.getMyPodcastListened().get(i).getCategory() == TypeCategory.POLITIC) {
                        totalReproductionPolitic += objStandard.getMyPodcastListened().get(i).getNumberOfReproduction();

                    } else if (objStandard.getMyPodcastListened().get(i).getCategory() == TypeCategory.VIDEOGAME) {
                        totalReproductionVideoGame += objStandard.getMyPodcastListened().get(i)
                                .getNumberOfReproduction();

                    }
                }
            } else if (objUser instanceof Premium) {
                Premium objPremium = (Premium) objUser;
                for (int i = 0; i < objPremium.getMyPodcastListened().size(); i++) {
                    if (objPremium.getMyPodcastListened().get(i).getCategory() == TypeCategory.ENTERTAIMENT) {
                        totalReproductionEntertaiment += objPremium.getMyPodcastListened().get(i)
                                .getNumberOfReproduction();
                    } else if (objPremium.getMyPodcastListened().get(i).getCategory() == TypeCategory.POLITIC) {
                        totalReproductionPolitic += objPremium.getMyPodcastListened().get(i).getNumberOfReproduction();
                    } else if (objPremium.getMyPodcastListened().get(i).getCategory() == TypeCategory.FASHION) {
                        totalReproductionFashion += objPremium.getMyPodcastListened().get(i).getNumberOfReproduction();
                    } else if (objPremium.getMyPodcastListened().get(i).getCategory() == TypeCategory.VIDEOGAME) {
                        totalReproductionVideoGame += objPremium.getMyPodcastListened().get(i)
                                .getNumberOfReproduction();
                    }
                }
            }
        }

        if (totalReproductionEntertaiment > totalReproductionFashion
                && totalReproductionEntertaiment > totalReproductionPolitic
                && totalReproductionEntertaiment > totalReproductionVideoGame && option == 2) {
            message = "The category most listened of: " + objUser.getNickName() + " is entertaiment with "
                    + totalReproductionEntertaiment + " reprodutions";
        } else if (totalReproductionFashion > totalReproductionEntertaiment
                && totalReproductionFashion > totalReproductionPolitic
                && totalReproductionFashion > totalReproductionVideoGame && option == 2) {
            message = "The category most listened of: " + objUser.getNickName() + " is fashion with "
                    + totalReproductionFashion + " reprodutions";
        } else if (totalReproductionPolitic > totalReproductionEntertaiment
                && totalReproductionPolitic > totalReproductionFashion
                && totalReproductionPolitic > totalReproductionVideoGame && option == 2) {
            message = "The category most listened of: " + objUser.getNickName() + " is politic with "
                    + totalReproductionPolitic + " reprodutions";
        } else if (totalReproductionVideoGame > totalReproductionEntertaiment
                && totalReproductionVideoGame > totalReproductionFashion
                && totalReproductionVideoGame > totalReproductionPolitic && option == 2) {
            message = "The category most listened of: " + objUser.getNickName() + "is videogame with "
                    + totalReproductionVideoGame + " reprodutions";
        }

        return message;
    }
    
    /**
     * name: SalesOfEachGenre
      * Reports the amount of sales of each genre and the profits generated
      * @return returns a message with the amount of sales of each genre and the profits generated
      * (There must be registered users, artists and songs)
      */
    public String salesOfEachGenre(){
        
        int stonksHouse=0;
        int stonksPop=0;
        int stonksRock=0;
        int stonksTrap=0;
        int totalSalesTrap=0;
        int totalSalesHouse=0;
        int totalSalesPop=0;
        int totalSalesRock=0;
        
        for (int i = 0; i < catalogueSongs.size(); i++) {

             if(catalogueSongs.get(i).getGender()==TypeGender.HOUSE){
                int numberOfSell=catalogueSongs.get(i).getNumberOfSell();
                totalSalesHouse+=numberOfSell;
                stonksHouse+=numberOfSell*catalogueSongs.get(i).getValue();
             }
             else if(catalogueSongs.get(i).getGender()==TypeGender.POP){
                int numberOfSell=catalogueSongs.get(i).getNumberOfSell();
                totalSalesPop+=numberOfSell;
                stonksPop+=numberOfSell*catalogueSongs.get(i).getValue();
             }
             else if(catalogueSongs.get(i).getGender()==TypeGender.ROCK){
                int numberOfSell=catalogueSongs.get(i).getNumberOfSell();
                totalSalesRock+=numberOfSell;
                stonksRock+=numberOfSell*catalogueSongs.get(i).getValue();
             }
             else if(catalogueSongs.get(i).getGender()==TypeGender.TRAP){
                int numberOfSell=catalogueSongs.get(i).getNumberOfSell();
                totalSalesTrap+=numberOfSell;
                stonksTrap+=numberOfSell*catalogueSongs.get(i).getValue();
             }
            
        }
         
        String message="The number of songs sold from genre house are "+totalSalesHouse+" with earnings of: "+stonksHouse+"$\nThe number of songs sold from genre pop are "+totalSalesPop+" with earnings of: "+stonksPop+"$\nThe number of songs sold from genre Rock are "+totalSalesRock+" With earnigs of: "+stonksRock+"$\nThe number of songs sold from genre rap are "+totalSalesTrap+" with earnigs of: "+stonksTrap+"$";
         
        return message;
    }

    // Get and Set

    public ArrayList<User> getUsers() {
        return users;
    }

    public void setUsers(ArrayList<User> users) {
        this.users = users;
    }

    public ArrayList<Audio> getAudios() {
        return catalogue;
    }

    public void setAudios(ArrayList<Audio> audios) {
        this.catalogue = audios;
    }

}
